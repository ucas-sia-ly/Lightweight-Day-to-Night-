# LaTeX paper

This directory contains the English IEEE Transactions-style manuscript for A2B-LightVPR.

Compile from this directory:

```bash
cd paper_latex
latexmk -pdf -interaction=nonstopmode main.tex
```

Compile from the repository root with automatic directory switching:

```bash
latexmk -cd -pdf -interaction=nonstopmode paper_latex/main.tex
```

Equivalent explicit sequence:

```bash
pdflatex -interaction=nonstopmode main.tex
bibtex main
pdflatex -interaction=nonstopmode main.tex
pdflatex -interaction=nonstopmode main.tex
```

The manuscript uses only the local `IEEEtran.cls` and standard TeX packages. The supplied `figures/fig1.png` and `figures/fig2.png` are used for the system overview and CDND candidate graph. The optional `temporal_pipeline.png` asset remains supported; when an asset is absent, a plain LaTeX placeholder is shown so the paper remains compilable. AI-generated diagrams are method illustrations, not experimental evidence. Numeric results were transcribed from `PAPER_ZH.md`, `runs/comparisons/cdnd_seed0_summary.json`, and the RobotCar temporal JSON files. The paper reports fixed-random-state-0 development results and does not claim cross-seed statistical significance.

The author, affiliation, and email fields in `main.tex` are placeholders and must be replaced before submission.
